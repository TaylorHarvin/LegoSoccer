
public class BallFinder {
	public BallFinder(MotionControl mainMotionControl){
		
	}
}

