<?php
	define('DUPLICATE_KEY', 1062);
?>