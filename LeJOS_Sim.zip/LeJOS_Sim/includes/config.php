<?php
	define('DB_HOST','localhost');
	//define('DB_HOST','mysql.cs.mtsu.edu');
	define('DB_NAME','lejos_sim');
	define('DB_USER','lejos_sim');
	define('DB_PASS','VYzRBH8T7SGtMCCt');
?>