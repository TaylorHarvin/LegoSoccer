// Copyright (c) 2002-2014 JavaMOP Team. All Rights Reserved.
package casino;

public class SlotMachine{
    public void insertCoin(){
    }
    public void push(){
    }
    public Integer getResult(){
        return null;
    }
}
