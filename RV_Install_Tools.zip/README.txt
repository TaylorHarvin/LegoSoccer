To install AspectJ, RV-Monitor, and JavaMOP:

- Run full_install.bat
-Run pathsetup.bat -- In !!!administrator mode!!!